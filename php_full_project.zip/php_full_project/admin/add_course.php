<?php
$db_con = mysqli_connect("localhost" , "root" , "" , "php full project");

if(isset($_POST['submit'])){
$name = $_POST['course'];

$insert = mysqli_query($db_con , "INSERT INTO `about`( `course`) VALUES ('$name')");
echo "ok";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
<input type="text" placeholder="course" name="course">
<input type="submit" name="submit" >
    </form>





    <!-- <form action="" method="post">
        <select name="" id="">
        <option value="Select Course">Select Course</option>
        <?php 
        // $course_data_select = mydqli_query($db_con , "SELECT * FROM `about`");
        //while($course_data_fatch = mysqli_fetch_assoc($course_data_select)){

        
        ?>
      <option value="<?//=$course_data_fatch['course'];?>"><?//=$course_data_fatch['course'];?></option>
        <?php  
        //}
        ?>
        </select>
    </form> -->
</body>
</html>