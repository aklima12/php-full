<!-- <?php 
// require('db_con.php');
// $id = $_GET['id'];
// $delete = "DELETE  FROM `student_admission_data` WHERE id = $id ";
// $delete_query = mysqli_query($db_con , $delete);
// if($delete_query){
//     echo '
//     <script>
//         alert("Successfull");
//     </script>
// ';

// }else{
//     echo '
//     <script>
//         alert("Problem");
//     </script>
// ';
// }
// header('location:admin_dashboard_index.php');
?> -->


<?php
require("db_con.php");
session_start();
if(!isset($_SESSION['user_login'])){
    header("location:admin_dashboard_index.php");
}

$u_id=base64_decode($_GET['id']);
$delete_query=mysqli_query($db_con,"DELETE FROM `student_admission_data` `id`='$u_id'");
if($delete_query){
    echo'
    <script>
    alert("Successfully Deleted");
    window.location.href="admin_dashboard_index.php?page=admin_dashboard_page";
    </script>
    ';
}

?>