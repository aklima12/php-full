<?php 
require("db_con.php");
session_start();
if(!isset($_SESSION['User_name'])){
    header("location:../login form/login_admin_index_form.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- css link start-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin_dashboard.css">
	<link rel="stylesheet" href="css/style.css">
    <!--css link end-->
	<!-- font-awesome cdn -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.1.4/dist/boxicons.js"></script>
    <title>Md Alif - Dashboard</title>
</head>

<body>
<div class="main_body">
	<div class="logo_and_profile_icon">
		<div class="l_a_p_i_row">
			<div class="l_a_p_i_col">
              <div class="logo">
				<img height="100px" src="images/logo.png" alt="">
			  </div>
			</div>
			<div class="l_a_p_i_col">
				<div class="notifaction">
				<i class="fa-solid fa-bell"></i>
				</div>
				
				<div class="user_photo" id="user_photo"  onclick="submenu()">
					<img  src="images/avator.png" alt="">
				</div>
				<div class="user_name">
					 bristy
					 <i class="fa-solid fa-caret-down " onclick="submenu()"></i>
				</div>
				 <ul class="profile_icon_sub_menu " style="display: none;" id="submenu">
				    <li class="d-block"><a href=""><i class="fa-solid fa-user"></i>View Profile</a></li>
					<li><a href=""><i class="fa-solid fa-gear"></i>Setting</a></li>
					<li><a href="../login form/logout.php"><i class="fa-solid fa-right-from-bracket"></i>Logout</a></li>
				 </ul>
			</div>
		</div>
	</div>
<script>
function submenu() {
  var x = document.getElementById('submenu');
  if (x.style.display === 'none') {
    x.style.display = 'block';
  } else {
    x.style.display = 'none';
  }
}
</script>

	<div class="container-fluid" style="padding-left:0;position:relative">
		<div class="row">
			<div class="col col-sm-12 col-md-12 col-lg-3 col-xxl-2">
			<nav class="sidebar card">
						<ul class="nav flex-column" id="nav_accordion">
							<li class="nav-item">
								<a class="list-group-item dashboard" href="admin_dashboard_index.php?page=admin_dashboard_page"><i class='bx bxs-dashboard'></i>Dashboard</a>
							</li>
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><span>Admission</span> <i style="text-align: right;" class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_dashboard_index.php?page=admin_user_addmission">Admission</a></li>
									<li><a class="nav-link" href="admin_dashboard_index.php?page=admission_list_page">Admission list</a></li>
								</ul>
							</li>
							<li class="nav-item has-submenu">
								<a class="nav-link list-group-item" href="#"><span>Teachers</span> <i style="text-align: right;" class="fa-solid fa-caret-down"></i></a>
								<ul class="submenu collapse">
									<li><a class="nav-link" href="admin_dashboard_index.php?page=add_teacher_page">Add Teacher </a></li>
									<li><a class="nav-link" href="admin_dashboard_index.php?page=teacher_list_page">Teacher List</a></li>
									<li><a class="nav-link" href="admin_dashboard_index.php?page=add_teacher_salary_page">Add Salary</a></li>
									<li><a class="nav-link" href="admin_dashboard_index.php?page=salary_list_page">Salary List</a></li>
								</ul>
							</li>	
							<li class="nav-item has-submenu">
						
								<a class="nav-link list-group-item" href="admin_dashboard_index.php?page=setting_page">Setting</a>
							</li>
							
							<li class="nav-item has-submenu">
						
						<a class="nav-link list-group-item" href="admin_dashboard_index.php?page=add_course">add_course</a>
					</li>	

						</ul>
					</nav>
			</div>
			<div class="col col-sm-12 col-md-12 col-lg-9 col-xxl-10">
                <?php 
				if(isset($_GET['page'])){
				$page=$_GET['page'].'.php';
				} else {
				$page='admin_dashboard.php';
				}
								
				if(file_exists($page)){
				require $page;
				} else {
					require '404.php';
				}				  
				?>
			</div>
		</div>
	</div>
</div>


<div class="footer-bottom" style="margin:0;">
<div class="copyright"><p>Copyright  2012 FCTI Inc all rights reserved | Powered by <a target="_blank" href="https://fctisoftware.com">FCTI</a></p></div>
</div>

<button id="scrollTopBtn"><i class="fa-solid fa-arrow-up"></i></button>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
<script>

</script>
</body>
</html>